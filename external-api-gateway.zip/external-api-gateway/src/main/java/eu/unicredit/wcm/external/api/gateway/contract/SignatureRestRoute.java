package eu.unicredit.wcm.external.api.gateway.contract;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestParamType;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SignatureRestRoute {

    @Bean
    public RouteBuilder createRouteBuilder() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                rest("/contracts")
                        .post("/signatures")
                        .id("signContractDocument")
                        .consumes("application/json")
                        .type(DocumentSignatureStatus.class)
                        .param().name("body").type(RestParamType.body).description("Document signature status").endParam()
                        .responseMessage().code(204).message("Signature accepted").endResponseMessage()
                        .to("direct:contract-signatures");

                from("direct:contract-signatures")
                        .setExchangePattern(ExchangePattern.InOnly)
                        .wireTap("activemq:queue:contracts.signatures")
                        .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(204))
                        .setBody(constant(""));
            }
        };
    }

}
