package eu.unicredit.wcm.external.api.gateway.configuration;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApiGatewayConfiguration {

    @Bean
    public RouteBuilder configuration() {
        return new RouteBuilder() {
            @Override
            public void configure() {
                restConfiguration()
                        .component("servlet")
                        .bindingMode(RestBindingMode.auto)
                        .enableCORS(true)
                        .contextPath("/api/*")
                        .apiContextPath("/api-doc")
                        .apiProperty("api.title", "WCM Gateway")
                        .apiProperty("api.version", "1.0.0");
            }
        };
    }
}
