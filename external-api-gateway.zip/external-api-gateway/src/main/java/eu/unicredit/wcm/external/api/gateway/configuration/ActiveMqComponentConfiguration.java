package eu.unicredit.wcm.external.api.gateway.configuration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ActiveMqComponentConfiguration {

}
