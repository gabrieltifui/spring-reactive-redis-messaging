package eu.unicredit.wcm.external.api.gateway.contract;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Represents a document signature status")
public class DocumentSignatureStatus {

    @ApiModelProperty(required = true, value = "The ID of the document")
    public String documentId;

    @ApiModelProperty(required = true, value = "The DIG process id")
    public String digProcessId;

    @ApiModelProperty(required = true, value = "The document signature status")
    public String documentStatus;

}
