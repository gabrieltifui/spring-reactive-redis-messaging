package eu.unicredit.wcm.external.api.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExternalApiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExternalApiGatewayApplication.class, args);
    }

}
